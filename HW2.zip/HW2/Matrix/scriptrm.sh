	for((j=1;j<11;j++))
		do
			rm mat$j
		done
rm performance.dat
rm mat
rm pa
