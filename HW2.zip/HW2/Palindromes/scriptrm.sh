	for((j=1;j<11;j++))
		do
			rm pal$j
		done
rm performance.dat
rm pal
rm pa
