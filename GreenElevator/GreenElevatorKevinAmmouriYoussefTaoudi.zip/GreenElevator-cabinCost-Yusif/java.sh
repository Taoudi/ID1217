cd elevator
java -classpath classes elevator.Elevators -number $1 -top $2 -tcp
cd ..
