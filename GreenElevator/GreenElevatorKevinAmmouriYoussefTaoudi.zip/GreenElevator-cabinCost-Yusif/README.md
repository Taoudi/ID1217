# Project for course ID1217 at KTH - Kevin Ammouri, Youssef Taoudi

## To run the program, execute bash scripts with arguments below.
### First:
Run java.sh [elevator] [floors]

### Second:
Run c.sh [elevator] [floors]
