./bear $1 $2
