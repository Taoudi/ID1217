./bird $1 $2
