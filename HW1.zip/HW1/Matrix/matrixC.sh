gcc matrixC.c -o matrixC.c
