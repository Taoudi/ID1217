gcc matrixB.c -o matrixB
