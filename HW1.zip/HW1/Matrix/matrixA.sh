gcc matrixA.c -o matrixA
