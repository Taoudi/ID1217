g++ palindromes.c -o pal -O2

